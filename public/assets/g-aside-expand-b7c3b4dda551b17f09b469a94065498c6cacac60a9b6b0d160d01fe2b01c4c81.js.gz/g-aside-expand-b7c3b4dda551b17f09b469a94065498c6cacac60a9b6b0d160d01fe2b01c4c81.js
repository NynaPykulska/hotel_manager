$("#g-aside-expand").click(function() {
    $(".g-aside").toggleClass("g-aside-expanded");
    $(".g-aside-has-aside").toggleClass("g-application-content-expanded");
});
